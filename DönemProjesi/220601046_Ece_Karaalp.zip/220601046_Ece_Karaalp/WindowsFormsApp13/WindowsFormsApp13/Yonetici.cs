﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp13
{
    internal class Yonetici
    {
        public Yonetici()
        {
            
        }
        
        public void FilmEkle()
        {

        }
         public void FilmGuncelle()
        {

        }
    }
}
